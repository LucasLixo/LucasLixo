package com.cornflower.tube

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
