<div align="center">

<img src="fastlane/icon.png" width=160 height=160 align="center">

# Tube Load

### Filmes/Séries para Android

[![GitHub release](https://img.shields.io/github/v/release/LucasLixo/Tube-Load?color=black&label=Stable&logo=github)](https://github.com/LucasLixo/Tube-Load/releases/latest/)
[![Changelog](https://img.shields.io/badge/Changelog-lightgray?style=flat&color=gray&logo=keep-a-changelog)](https://github.com/LucasLixo/Tube-Load/blob/main/CHANGELOG.md)
[![GitHub all releases](https://img.shields.io/github/downloads/LucasLixo/Tube-Load/total?label=Downloads&logo=github)](https://github.com/LucasLixo/Tube-Load/releases/)

</div>

## 📱 Screenshots

<div align="center">
<div>
<img src="fastlane/screenshot (1).jpg" width="24%" />
<img src="fastlane/screenshot (2).jpg" width="24%" />
<img src="fastlane/screenshot (3).jpg" width="24%" />
<img src="fastlane/screenshot (4).jpg" width="24%" />
</div>
</div>

<br>

## 📖 Características

>[!NOTE]
>
>Foco em performance.
- Tube Load é um aplicativo player de músicas do celular.
- Utiliza as bibliotecas [Just Audio](https://pub.dev/packages/just_audio) e [Just Audio Background](https://pub.dev/packages/just_audio_background) para serviços de áudio.

## ⬇️ Download

- Baixe a versão estável mais recente em [GitHub releases](https://github.com/LucasLixo/Tube-Load/releases/latest)
- Instale o [pre-release](https://github.com/LucasLixo/Tube-Load/releases/) versões para testar novos recursos e mudanças

## 🧱 Créditos

- Utiliza as bibliotecas [Just Audio](https://pub.dev/packages/just_audio) e [Just Audio Background](https://pub.dev/packages/just_audio_background).

## 📃 Licença

>[!WARNING]
>
>Todas as outras partes estão proibidas de usar o nome Tube Load como um aplicativo de streaming. 
Os derivados incluem, mas não estão limitados a, forks e versões não oficiais.

[![GitHub](https://img.shields.io/github/license/LucasLixo/Tube-Load?style=for-the-badge)](https://github.com/LucasLixo/Tube-Load/blob/main/LICENSE)

<div align="right">
<table><td>
<a href="#start-of-content">👆 Role para cima</a>
</td></table>
</div>
