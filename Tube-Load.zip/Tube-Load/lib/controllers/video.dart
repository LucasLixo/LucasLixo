import 'package:youtube_explode_dart/youtube_explode_dart.dart';

class VideoController extends YoutubeExplode {
}
