import 'package:get/get.dart';

class VideoStateController extends GetxController {

  RxDouble videoDuration = 0.0.obs;
  RxDouble videoPosition = 0.0.obs;
}