import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:tube/controllers/video_export.dart';
import 'package:tube/utils/colors.dart';
import 'package:tube/utils/text_style.dart';

class Home extends StatefulWidget {
  const Home({super.key});

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  late TextEditingController _textController;
  final videoController = VideoController();

  List<dynamic>? videoInfo;

  String formatSelected = 'mp4';
  bool isLoaded = false;

  @override
  void initState() {
    super.initState();
    _textController = TextEditingController();
  }

  @override
  void dispose() {
    _textController.dispose();
    super.dispose();
  }

  Future<void> _pasteFromClipboard() async {
    ClipboardData? clipboardData = await Clipboard.getData('text/plain');
    if (clipboardData != null) {
      _textController.text = clipboardData.text!;
    }
  }

  Future<void> _searchFromClipboard() async {
    isLoaded = true;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: colorBackgroundDark,
      appBar: AppBar(
        backgroundColor: colorBackgroundDark,
        title: Text('Tube Load', style: textStyle(fontSize: 24)),
      ),
      body: Stack(
        children: [
          if (isLoaded)
            const Positioned(
              top: 0,
              left: 0,
              right: 0,
              child: LinearProgressIndicator(
                color: colorPrimary,
                backgroundColor: colorBackground,
              ),
            ),
          Padding(
            padding: const EdgeInsets.fromLTRB(8, 14, 8, 8),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Link',
                  style: textStyle(),
                ),
                TextField(
                  controller: _textController,
                  style: textStyle(),
                  maxLines: null,
                  minLines: 1,
                  maxLength: 256,
                  decoration: InputDecoration(
                    border: const OutlineInputBorder(
                      borderSide: BorderSide(color: colorPrimary),
                    ),
                    enabledBorder: const OutlineInputBorder(
                      borderSide: BorderSide(color: colorPrimary, width: 2.0),
                    ),
                    focusedBorder: const OutlineInputBorder(
                      borderSide: BorderSide(color: colorPrimary, width: 2.0),
                    ),
                    hintStyle: textStyle(),
                    suffixIcon: IconButton(
                      icon: const Icon(Icons.paste, color: colorWhite),
                      onPressed: _pasteFromClipboard,
                    ),
                  ),
                ),
                Text(
                  'Format',
                  style: textStyle(),
                ),
                const Divider(
                  color: colorBackground,
                ),
                Card(
                  color: Colors.black,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      ClipRect(
                        child: Image.network(
                          'https://img.youtube.com/vi/FZUB-ZSP0RU/hqdefault.jpg',
                          width: double.infinity,
                          height: 240,
                          fit: BoxFit.contain,
                        ),
                      ),
                      ListTile(
                        tileColor: colorBackground,
                        leading: ClipOval(
                          child: Image.network(
                            'https://yt3.ggpht.com/ytc/AIdro_lVOrsAQ5Qxzi3Kv0ugiVEzi27Zew2jjd20_VXq3KPR1tA=s48-c-k-c0x00ffffff-no-rj',
                            width: 50,
                            height: 50,
                            fit: BoxFit.cover,
                          ),
                        ),
                        title: const Text(
                          'yun li - going home ft the merk (prod biffe)',
                          style: TextStyle(
                            fontFamily: bold,
                            color: colorWhite,
                          ),
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                        subtitle: const Text(
                          'YUNG LIXO',
                          style: TextStyle(
                            color: colorWhiteGray,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
      floatingActionButton: _textController.text.isNotEmpty
          ? FloatingActionButton(
              onPressed: _searchFromClipboard,
              tooltip: 'Download',
              backgroundColor: colorPrimary,
              child: const Icon(Icons.download),
            )
          : null,
    );
  }
}
